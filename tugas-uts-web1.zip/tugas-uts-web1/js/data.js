// Dummy Data File

const meDataKatalog = [
    { id: "B001", judul: "Pemrograman Web Modern", penulis: "Budi Santoso", harga: 85000, stok: 15, gambar: "img/buku1.png" },
    { id: "B002", judul: "Belajar JavaScript DOM", penulis: "Siti Aminah", harga: 75000, stok: 8, gambar: "img/buku2.png" },
    { id: "B003", judul: "Panduan CSS Grid & Flexbox", penulis: "Eko Prasetyo", harga: 65000, stok: 20, gambar: "img/buku1.png" },
    { id: "B004", judul: "Mastering HTML5 & Semantics", penulis: "Rina Wijaya", harga: 90000, stok: 5, gambar: "img/buku2.png" }
];

const meDataPengiriman = [
    {
        noDO: "DO-2023001",
        pemesan: "Ahmad Dahlan",
        status: "Dalam Pengiriman",
        progress: 75,
        ekspedisi: "JNE Express",
        tanggalKirim: "2023-10-24",
        jenisPaket: "Reguler",
        total: 160000
    },
    {
        noDO: "DO-2023002",
        pemesan: "Siti Nurhaliza",
        status: "Tiba di Tujuan",
        progress: 100,
        ekspedisi: "J&T Express",
        tanggalKirim: "2023-10-22",
        jenisPaket: "Express",
        total: 95000
    }
];

const meDataHistory = [
    { idTrx: "TRX-101", tanggal: "2023-10-20", total: 160000, status: "Selesai" },
    { idTrx: "TRX-102", tanggal: "2023-10-22", total: 95000, status: "Selesai" }
];
