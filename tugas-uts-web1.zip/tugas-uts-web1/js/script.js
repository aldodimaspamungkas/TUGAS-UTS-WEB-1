// Main JavaScript File

document.addEventListener("DOMContentLoaded", () => {
    initGreeting();
    initKatalog();
    initCheckout();
    initTracking();
});

// Greeting Function
function initGreeting() {
    const greetingEl = document.getElementById("greetingText");
    if (!greetingEl) return;

    const hour = new Date().getHours();
    let greeting = "";

    if (hour >= 5 && hour < 12) {
        greeting = "Selamat Pagi ☀️";
    } else if (hour >= 12 && hour < 15) {
        greeting = "Selamat Siang 🌤️";
    } else if (hour >= 15 && hour < 18) {
        greeting = "Selamat Sore 🌅";
    } else {
        greeting = "Selamat Malam 🌙";
    }

    greetingEl.innerText = `${greeting}, Selamat Datang di Toko Buku Online!`;
}

// Login & Modal Functions
function handleLogin(event) {
    event.preventDefault();
    const email = document.getElementById("email").value;
    const password = document.getElementById("password").value;

    if (email === "user@gmail.com" && password === "123456") {
        alert("Login Berhasil! Mengalihkan ke Dashboard...");
        window.location.href = "dashboard.html";
    } else {
        alert("Email atau password yang Anda masukkan salah!");
    }
}

function openModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) modal.style.display = "flex";
}

function closeModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) modal.style.display = "none";
}

// Katalog Functions
function initKatalog() {
    const tableBody = document.querySelector("#stokTable tbody");
    if (!tableBody) return;

    renderKatalogTable();
}

function renderKatalogTable() {
    const tableBody = document.querySelector("#stokTable tbody");
    tableBody.innerHTML = "";

    meDataKatalog.forEach((buku) => {
        const tr = document.createElement("tr");
        tr.innerHTML = `
            <td>${buku.id}</td>
            <td>${buku.judul}</td>
            <td>${buku.penulis}</td>
            <td>Rp ${buku.harga.toLocaleString("id-ID")}</td>
            <td>${buku.stok}</td>
        `;
        tableBody.appendChild(tr);
    });
}

function tambahStokBaru(event) {
    event.preventDefault();
    const id = document.getElementById("bukuId").value;
    const judul = document.getElementById("bukuJudul").value;
    const penulis = document.getElementById("bukuPenulis").value;
    const harga = parseInt(document.getElementById("bukuHarga").value);
    const stok = parseInt(document.getElementById("bukuStok").value);

    meDataKatalog.push({ id, judul, penulis, harga, stok, gambar: "img/buku1.png" });
    renderKatalogTable();
    closeModal("modalTambahBuku");
    document.getElementById("formTambahBuku").reset();
    alert("Stok buku berhasil ditambahkan!");
}

// Checkout Functions
let cart = [
    { id: "B001", judul: "Pemrograman Web Modern", harga: 85000, qty: 1 }
];

function initCheckout() {
    const cartBody = document.querySelector("#cartTable tbody");
    if (!cartBody) return;

    renderCart();
}

function renderCart() {
    const cartBody = document.querySelector("#cartTable tbody");
    if (!cartBody) return;
    
    cartBody.innerHTML = "";
    let grandTotal = 0;

    cart.forEach((item, index) => {
        const total = item.harga * item.qty;
        grandTotal += total;

        const tr = document.createElement("tr");
        tr.innerHTML = `
            <td>${item.judul}</td>
            <td>Rp ${item.harga.toLocaleString("id-ID")}</td>
            <td>
                <input type="number" min="1" value="${item.qty}" onchange="updateQty(${index}, this.value)" style="width: 60px;">
            </td>
            <td>Rp ${total.toLocaleString("id-ID")}</td>
            <td><button type="button" class="btn btn-secondary" onclick="hapusCart(${index})" style="padding: 4px 8px; font-size: 12px;">Hapus</button></td>
        `;
        cartBody.appendChild(tr);
    });

    document.getElementById("grandTotal").innerText = `Rp ${grandTotal.toLocaleString("id-ID")}`;
}

function updateQty(index, value) {
    cart[index].qty = parseInt(value) || 1;
    renderCart();
}

function hapusCart(index) {
    cart.splice(index, 1);
    renderCart();
}

function handleCheckout(event) {
    event.preventDefault();
    if (cart.length === 0) {
        alert("Keranjang pemesanan kosong!");
        return;
    }
    alert("Pemesanan Berhasil diproses! Terima kasih telah berbelanja.");
    window.location.href = "dashboard.html";
}

// Tracking Function
function initTracking() {
    const trackingResult = document.getElementById("trackingResult");
    if (!trackingResult) return;
}

function cariDO() {
    const noDO = document.getElementById("inputDO").value.trim();
    const resultDiv = document.getElementById("trackingResult");

    const data = meDataPengiriman.find(item => item.noDO.toLowerCase() === noDO.toLowerCase());

    if (!data) {
        alert("Nomor Delivery Order (DO) tidak ditemukan! Cobalah: DO-2023001 atau DO-2023002");
        resultDiv.style.display = "none";
        return;
    }

    document.getElementById("resNama").innerText = data.pemesan;
    document.getElementById("resStatus").innerText = data.status;
    document.getElementById("resEkspedisi").innerText = data.ekspedisi;
    document.getElementById("resTanggal").innerText = data.tanggalKirim;
    document.getElementById("resPaket").innerText = data.jenisPaket;
    document.getElementById("resTotal").innerText = `Rp ${data.total.toLocaleString("id-ID")}`;

    const progressBar = document.getElementById("progressBar");
    progressBar.style.width = `${data.progress}%`;

    resultDiv.style.display = "block";
}
